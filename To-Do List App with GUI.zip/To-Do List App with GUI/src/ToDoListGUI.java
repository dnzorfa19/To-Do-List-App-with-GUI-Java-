import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public class ToDoListGUI {

    private JFrame frame;
    private DefaultListModel<String> taskListModel;
    private JList<String> taskList;
    private JTextField taskInput;
    private final String FILE_NAME = "tasks.txt"; // Görevleri kaydetmek için dosya

    public ToDoListGUI() {
        frame = new JFrame("To-Do List");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setLayout(new BorderLayout());

        // Görev listesi
        taskListModel = new DefaultListModel<>();
        taskList = new JList<>(taskListModel);
        JScrollPane scrollPane = new JScrollPane(taskList);
        frame.add(scrollPane, BorderLayout.CENTER);

        // Alt panel (input + butonlar)
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        taskInput = new JTextField();
        panel.add(taskInput, BorderLayout.NORTH);

        // Buton paneli
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 6, 5, 5));

        JButton addButton = new JButton("Ekle");
        JButton editButton = new JButton("Güncelle");
        JButton doneButton = new JButton("Tamamla");
        JButton deleteButton = new JButton("Sil");
        JButton saveButton = new JButton("Kaydet");
        JButton exitButton = new JButton("Çıkış");

        buttonPanel.add(addButton);
        buttonPanel.add(editButton);
        buttonPanel.add(doneButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(saveButton);
        buttonPanel.add(exitButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);
        frame.add(panel, BorderLayout.SOUTH);

        // Buton işlemleri
        addButton.addActionListener(e -> addTask());
        editButton.addActionListener(e -> editTask());
        doneButton.addActionListener(e -> markTaskDone());
        deleteButton.addActionListener(e -> deleteTask());
        saveButton.addActionListener(e -> saveTasks());
        exitButton.addActionListener(e -> {
            saveTasks();
            System.exit(0);
        });

        taskInput.addActionListener(e -> addTask());

        // Önceki görevleri dosyadan yükle
        loadTasks();

        frame.setVisible(true);
    }

    private void addTask() {
        String task = taskInput.getText().trim();
        if (!task.isEmpty()) {
            taskListModel.addElement("[ ] " + task);
            taskInput.setText("");
        }
    }

    private void editTask() {
        int index = taskList.getSelectedIndex();
        if (index != -1) {
            String currentTask = taskListModel.getElementAt(index);
            String newTask = JOptionPane.showInputDialog(frame, "Görev güncelle:", currentTask.substring(3));
            if (newTask != null && !newTask.trim().isEmpty()) {
                String status = currentTask.startsWith("[✔]") ? "[✔] " : "[ ] ";
                taskListModel.set(index, status + newTask.trim());
            }
        } else {
            JOptionPane.showMessageDialog(frame, "Lütfen güncellemek için bir görev seçin!");
        }
    }

    private void markTaskDone() {
        int index = taskList.getSelectedIndex();
        if (index != -1) {
            String task = taskListModel.getElementAt(index);
            if (!task.startsWith("[✔]")) {
                taskListModel.set(index, "[✔] " + task.substring(3));
            }
        }
    }

    private void deleteTask() {
        int index = taskList.getSelectedIndex();
        if (index != -1) {
            taskListModel.remove(index);
        }
    }

    private void saveTasks() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (int i = 0; i < taskListModel.size(); i++) {
                writer.write(taskListModel.get(i));
                writer.newLine();
            }
            JOptionPane.showMessageDialog(frame, "Görevler kaydedildi!");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Görevler kaydedilemedi: " + e.getMessage());
        }
    }

    private void loadTasks() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                taskListModel.addElement(line);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Görevler yüklenemedi: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ToDoListGUI::new);
    }
}
